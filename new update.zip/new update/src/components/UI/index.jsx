import TableHead from "./TableHead";
import TableRow from "./TableRow";

export { TableHead, TableRow };
